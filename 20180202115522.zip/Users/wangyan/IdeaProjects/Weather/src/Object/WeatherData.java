package Object;

import Interface.Observer;
import Interface.Subject;

import java.util.ArrayList;

/**
 * Created by wangyan on 2017/12/12.
 */

public class WeatherData implements Subject {
    private ArrayList observers;
    private float temperature;
    private float humidity;
    private float pressure;

    public WeatherData ( ){
        observers = new ArrayList ( );
    }

    @Override
    public void registerObserver(Observer o) {
        observers.add(o);
    }

    @Override
    public void removeObserver(Observer o) {
        int j = observers.indexOf(o);
        if (j >= 0) {
            observers.remove(j);
        }
    }

    @Override
    public void notifyObservers() {
        for (int j = 0; j < observers.size(); j++) {
            Observer observer = (Observer)observers.get(j);
            observer.update(temperature, humidity, pressure);
        }
    }

    //Notify the observers when measurements change.
    public void measurementsChanged ( ) {
        notifyObservers ( );
    }
    // add a set method for testing + other methods.}

}
