package Object;

/**
 * Created by wangyan on 2017/12/12.
 */
public class ShangHaiWeatherData  extends WeatherData{
    private String position;
}
