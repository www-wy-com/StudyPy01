package Object;

import Interface.DisplayElement;
import Interface.Observer;
import Interface.Subject;

/**
 * Created by wangyan on 2017/12/12.
 */
public class CurrentConditionsDisplay implements Observer, DisplayElement {
    private float temperature;
    private float humidity;
    private Subject weatherData;

    public CurrentConditionsDisplay(Subject weatherDataS) {
        this.weatherData = weatherDataS;
        weatherData.registerObserver (this);
    }


    @Override
    public void update(float temperature, float humidity, float pressure) {
        this.temperature = temperature;
        this.humidity = humidity;
        display ( );
    }

    @Override
    public void display() {
        System.out.println( "Current conditions :" + temperature + "F degrees  and " + humidity + "% humidity" );

    }
}
