package Interface;

/**
 * Created by wangyan on 2017/12/12.
 */
public interface Subject {
    void registerObserver(Observer o);
    void removeObserver(Observer o);
    void notifyObservers();
}
