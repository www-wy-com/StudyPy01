package Interface;

/**
 * Created by wangyan on 2017/12/12.
 */
public interface Observer {
    void update(float temp, float humidity, float pressure);

}
